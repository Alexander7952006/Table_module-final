from package import (csv_module, pickle_module, txt_module, tools)

#table = csv_module. load_table('C:\\Users\\Alex\\Desktop\\Package project\\files\\test.csv')

#table = pickle_module. load_table('C:\\Users\\Alex\\Desktop\\Package project\\files\\test.pickle')

#print(table)

#print(tools. get_rows_by_number(table, 1, 3, copy_table = True))

#print(tools. get_column_types(table))

#print(tools. get_rows_by_index(table,'Долгов', 'Алексеев', copy_table = True))

#print(tools. get_value(table, 'Фамилия'))

#print(tools. get_values(table, 'ЗП'))

#print(tools. print_table(table))

#print(tools. set_column_types(table, {3: float, 4: float, 5: float}))

#print(tools. set_value(table, 'Третьяк', 1))

#print(tools. set_values(table, ['Третьяк', 'Третьяк', 'Третьяк', 'Третьяк'], 1))

#print(table)

#csv_module. save_table(table, 'C:\\Users\\Alex\\Desktop\\Package project\\files\\txt_table.csv')
#pickle_module. save_table(table, 'C:\\Users\\Alex\\Desktop\\Package project\\files\\txt_table.pickle')
#txt_module. save_table(table, 'C:\\Users\\Alex\\Desktop\\Package project\\files\\txt_table.txt')



